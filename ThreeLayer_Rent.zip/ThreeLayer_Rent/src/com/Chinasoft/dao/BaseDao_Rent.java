package com.Chinasoft.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class BaseDao_Rent{
	
	private Connection con;
	private PreparedStatement prs;
	private ResultSet rst;
	private String url="jdbc:mysql://localhost:3306/rent?characterEncoding=utf8";
	
	//��������
	public BaseDao_Rent() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��������
	public void getConn() {
		try {
			con=DriverManager.getConnection(url,"root","3141592654");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public ResultSet getRes(String sql){
		return getRes(sql,new Object[] {});
	}
	
	public ResultSet getRes(String sql,Object [] obj){
		getConn();
		try {
			prs=con.prepareStatement(sql);
			if(obj.length>0) {
				for(int i=0;i<obj.length;i++) {
					prs.setObject(i+1, obj[i]);
				}
			}
			//System.out.println(prs.toString());
			rst=prs.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return rst;
	}
	
	public int getUpda(String sql,Object []obj) {
		getConn();
		int count=0;
		try {
			prs=con.prepareStatement(sql);
			if(obj.length>0) {
				for(int i=0;i<obj.length;i++) {
					prs.setObject(i+1, obj[i]);
				}
			}
			//System.out.println(prs.toString());
			count=prs.executeUpdate();
			
			//if(count>0) {System.out.println("�����ɹ�");}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		closeAll();
		return count;
		
	}
	
	public void closeAll() {
		
		try {
			if(rst!=null) {rst.close();}
			if(prs!=null) {prs.close();}
			if(con!=null) {con.close();}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
}
