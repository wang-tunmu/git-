package com.Chinasoft.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Chinasoft.Pojo.User;
import com.Chinasoft.Pojo.Vip;

public class VipDao extends BaseDao_Rent{
	
//��ѯ-�û�
	public List<Vip> selectV(User us) {
		List<Vip>list=new ArrayList<Vip>();
		ResultSet rsm=getRes("select * from vip where uname='"+us.getUname()+"'");//String��ƴ����Ҫע���ʽ-sql�����Ҫ������
		try {
			while(rsm.next()) {
				Vip v=new Vip(rsm.getInt("vid"),rsm.getString("uname"),rsm.getString("opentime"),rsm.getString("limittime"));
				list.add(v);
			}
		} catch (SQLException e) {}//������
		
		return list;
	}
	
//����Ա-����ʱ�䡢����ʱ��
	public void newVip(User us,Vip v) {
		ResultSet rs= getRes("select max(vid) from vip");
		int i=1;
			try {
				if(rs.next()) {
					i=rs.getInt(1)+1;
				}
			} catch (SQLException e) {}//û��������i=1�����쳣
			
		String sql="insert into vip values(?,?,?,?)";
		Object [] obj= {i,v.getUname(),v.getOpentime(),v.getLimittime()};
		getUpda(sql, obj);//����Ա��Ϣ�־û�
	}
	
//��ѯ-����Ա
	public List<Vip> selectVByAdmin(Vip v){
		List<Vip>list=new ArrayList<Vip>();
		
		StringBuffer sql=new StringBuffer("select * from vip where vid>0");
		if(v.getVid()!=0) {
			sql.append(" and vid="+v.getVid());
		}
		if(v.getUname()!=null) {
			sql.append(" and uname like '%"+v.getUname()+"%'");//ģ����ѯ
		}
		if(v.getOpentime()!=null) {
			sql.append(" and opentime like '%"+v.getOpentime()+"%'");
		}
		if(v.getLimittime()!=null) {
			sql.append(" and limittime like '%"+v.getLimittime()+"%'");
		}
		
		ResultSet rs=getRes(sql.toString());
		
		try {
			while(rs.next()) {
				Vip vip=new Vip(rs.getInt("vid"),rs.getString("uname"),rs.getString("opentime"),rs.getString("limittime"));
				list.add(vip);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
//�û�����--����Ա
	public void deleteV(int vid,String newLtime) {
		
		
		String sql="update vip set limittime=? where vid=?";
	}
	
	
}
