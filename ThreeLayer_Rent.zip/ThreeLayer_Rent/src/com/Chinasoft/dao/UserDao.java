package com.Chinasoft.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Chinasoft.Pojo.Car;
import com.Chinasoft.Pojo.User;

public class UserDao extends BaseDao_Rent{
	
	//ע��
	public void post(Object[] obj) {
		//��ѯ�����
		ResultSet rs=getRes("select max(uid) from user");
		try {
			rs.next();
			int num=rs.getInt(1)+1;
			rs.close();
			obj[0]=num;//����Ŵ���obj
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getUpda("insert into user values(?,?,?,1,?,?,?)", obj);
		
	}

	//��¼
	 public User judge(String uname) { 
		 Object []obj=new Object[] {uname};
		 ResultSet rs=getRes("select * from user where uname=?", obj); 
		 User user=null; 
	 try { 
		 if(rs.next()) {
			 user=new User(rs.getInt("uid"),rs.getString("uname"),rs.getString("upassword"),rs.getInt("power"),
					 rs.getString("idname"),rs.getString("idcard"),rs.getString("phonenumber"));
					 } 
	 return user;
	 } catch (SQLException e) { // TODO Auto-generated catch block
	  e.printStackTrace(); }
	 return null;
	 }
	

	//��ֵ��Ա
	public void getVIP(String uname) {
		Object [] obj=new Object[] {uname};
		getUpda("update user set power=2 where uname=?", obj);
	}
	
	//����Ա��ѯ����
	public List<User>  getUserByInfo(User u){
		
		StringBuffer sql=new StringBuffer("select * from user where power in(1,2)");//���л�Ա����ͨ�û�
		if(u.getUid()!=0) {
			sql.append(" and uid="+u.getUid());
		}
		if(u.getUname()!=null) {
			sql.append(" and uname like '%"+u.getUname()+"%'");//ģ��
		}
		if(u.getPower()!=0) {
			sql.append(" and power="+u.getPower());
		}
		if(u.getIdname()!=null) {
			sql.append(" and idname like'%"+u.getIdname()+"%'");
		}
		if(u.getIdcard()!=null) {
			sql.append(" and idcard like'%"+u.getIdcard()+"%'");
		}
		if(u.getPhonenumber()!=null) {
			sql.append(" and phonenumber like'%"+u.getPhonenumber()+"%'");
		}
		
		//System.out.println(sql.toString());
		ResultSet rs= getRes(sql.toString());//��ѯ
		List<User> list=new ArrayList<User>();
		User user=null;
		try {
			while(rs.next()) {
				user=new User(rs.getInt("uid"),rs.getString("uname"),"******",rs.getInt("power"),rs.getString("idname"),
						rs.getString("idcard"),rs.getString("phonenumber"));
				list.add(user);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		}
	
	//����Ա�޸��û�Ȩ��-��Ա���ڽ���
	public void changeVIP(int p,String uname) {
		Object [] obj=new Object[] {p,uname};
		getUpda("update user set power=? where uname=?",obj);
	}
	
	
}
