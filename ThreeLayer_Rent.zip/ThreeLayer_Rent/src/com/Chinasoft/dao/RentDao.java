package com.Chinasoft.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import com.Chinasoft.Pojo.Car;
import com.Chinasoft.Pojo.Rent;
import com.Chinasoft.Pojo.User;

public class RentDao extends BaseDao_Rent{
	
	//��ѯ��¼
	public List<Rent> getByUser(User us) {
		ResultSet rs= getRes("select * from rent where uname=?",new Object[] {us.getUname()});
		List<Rent> list=new ArrayList<Rent>();
		Rent ren=null;
		try {
			while(rs.next()) {
		ren=new Rent(rs.getInt("rid"),rs.getString("uname"),rs.getInt("cid"),rs.getString("rtime"),rs.getString("btime"),rs.getDouble("money"));
				list.add(ren);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return null;
	}
	
//����Ա��ѯ
	public List<Rent> getByAdmin(Rent r){
		StringBuffer sql=new StringBuffer("select * from rent where rid>0");
		if(r.getRid()!=0) {
			sql.append(" and rid="+r.getRid());
		}
		if(r.getUname()!=null) {
			sql.append(" and uname='"+r.getUname()+"'");
		}
		if(r.getCid()!=0) {
			sql.append(" and cid="+r.getCid());
		}
		if(r.getRtime()!=null) {
			sql.append(" and rtime like '%"+r.getRtime()+"%'");//ģ����ѯ�������õļ�¼
		}
		if(r.getBtime()!=null) {
			sql.append(" and btime like '%"+r.getBtime()+"%'");//���컹���ļ�¼
		}
		//System.out.println(sql.toString());
		ResultSet rs=getRes(sql.toString());
		List<Rent> list=new ArrayList<Rent>();
		Rent ren=null;
		try {
			while(rs.next()) {
		ren=new Rent(rs.getInt("rid"),rs.getString("uname"),rs.getInt("cid"),rs.getString("rtime"),rs.getString("btime"),rs.getDouble("money"));
				list.add(ren);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return null;
	}
	
	
	//�⳵��Ϣ�־û�
	public void writeRecord(String uname,int cid) {
		Date date=new Date();
		SimpleDateFormat simp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String rtime=simp.format(date);//���ַ�����ʽ�������ݿ⣨���Զ�ת������ȡ����תΪDate
		
		/*
		 * long l=date.getTime(); java.sql.Date rtime = new java.sql.Date(l);
		 * System.out.println(rtime);
		 */
		/*
		 * Date rtime=null; try { rtime=(Date) sdf.parse(nowTime);//�õ����Դ������ݿ������ } catch
		 * (ParseException e1) { // TODO Auto-generated catch block
		 * e1.printStackTrace(); }
		 */
		
		Object[]obj =new Object[] {0,uname,cid,rtime,null,0};
		ResultSet rs=getRes("select max(rid) from rent");
		try {
			rs.next();
			int num=rs.getInt(1)+1;
			rs.close();
			obj[0]=num;//����Ŵ���obj
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql="insert into rent values(?,?,?,?,?,?)";
		getUpda(sql, obj);//������Ϣ�������ݿ�ɹ�
	}
	
	
	//����ʱ��־û�	
	public String updateRtime(User us) {
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String btime=sdf.format(date);//ֱ�Ӵ�String�����ݿ�
		/*
		 * Date btime=null; try { btime=sdf.parse(nowTime); } catch (ParseException e1)
		 * { // TODO Auto-generated catch block e1.printStackTrace(); }
		 */
		
		Object []obj1 = new Object[] {us.getUname()};//��ѯ
		String sql1="select max(rid) from rent where uname=?";
		ResultSet rs= getRes(sql1, obj1);//��ѯδ�����ļ�¼���
		int num=0;
		try {
			if(rs.next()) {
				num=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Object [] obj2=new Object[] {btime,num};//���ݲ鵽�ı�����ӻ���ʱ��
		String sql2="update rent set btime=? where rid=?";
		getUpda(sql2, obj2);//�޸����ݿ�
		return btime;
	}
	
	//���ѽ��־û�
	public void updateMoney(Rent re,double money) {
		Object [] obj=new Object[] {money,re.getRid()};//���ݲ鵽�ı�����ӻ���ʱ��
		String sql="update rent set money=? where rid=?";
		getUpda(sql, obj);//�޸����ݿ�
	}
	
	

}
