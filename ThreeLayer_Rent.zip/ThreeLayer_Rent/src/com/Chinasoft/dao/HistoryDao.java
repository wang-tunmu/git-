package com.Chinasoft.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.Chinasoft.Pojo.Car;
import com.Chinasoft.Pojo.History;
import com.Chinasoft.Pojo.User;

public class HistoryDao extends BaseDao_Rent{
	
	//��ѯ
	public List<History> getHistory(History his) {
		StringBuffer sql=new StringBuffer("select * from history where hid>0");
		if(his!=null){//his��Ϊ������Ҫ�������ݲ�ѯ	
			if(his.getHid()!=0) {
				sql.append(" and hid="+his.getHid());
			}
			if(his.getUname()!=null) {//ģ����ѯ
				sql.append(" and uname like'%"+his.getUname()+"%'");
			}
			if(his.getCid()!=0) {
				sql.append(" and cid="+his.getCid());
			}
			if(his.getUsername()!=null) {
				sql.append(" and username like'%"+his.getUsername()+"%'");
			}
			if(his.getHtime()!=null) {//ģ����ѯһ����
				sql.append(" and htime like'%"+his.getHtime()+"%'");
			}
			if(his.getHtype()!=null) {
				sql.append(" and htype like'%"+his.getHtype()+"%'");
			}
		}
		
		ResultSet rs= getRes(sql.toString());
		List<History> list=new ArrayList<History>();
		History hist=null;//��ѯ���ļ�¼
		try {
			while(rs.next()) {
				hist=new History(rs.getInt("hid"), rs.getString("uname"),rs.getInt("cid"),rs.getString("username"),
						rs.getString("htime"),rs.getString("htype"));
				list.add(hist);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	//�޸ļ�¼�־û�
	public void updaHistory(User us,Car c,User user,String htype) {
		Date date=new Date();
		SimpleDateFormat simp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String htime=simp.format(date);
		
		Object[] obj=null;
		ResultSet rs=getRes("select max(hid) from history");
		try {
			rs.next();
			int num=rs.getInt(1)+1;
			rs.close();
			if(c==null) {
				obj=new Object[] {num,us.getUname(),0,user.getUname(),htime,htype};//����Ŵ���obj
			}else {
				obj=new Object[] {num,us.getUname(),c.getCarid(),null,htime,htype};	
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sql="insert into history values(?,?,?,?,?,?)";
		
		getUpda(sql, obj);
	}
	
	
	
}
