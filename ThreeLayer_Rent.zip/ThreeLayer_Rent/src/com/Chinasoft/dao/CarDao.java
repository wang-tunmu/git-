package com.Chinasoft.dao;

import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Chinasoft.Pojo.Car;
import com.Chinasoft.Pojo.User;

public class CarDao extends BaseDao_Rent{
	
	//��ѯ
	public List<Car>  getCarByInfo(int power,Car c) throws UnsupportedEncodingException{
		String s=null;//�ּ���Ȩ
		if(power==3) {//����Ա
			s="select * from car where carid>0";//ȫ��������ɾ����Ҳ����
		}else if(power==2) {//��Ա
			s="select * from car where cstatus=1 and isdelete=0";
		}else {//��ͨ�û�
			s="select * from car where cstatus=1 and cgrade=1 and isdelete=0";
		}
		StringBuffer sql=new StringBuffer(s);

	if(c.getCarid()!=0) {
		sql.append(" and carid="+c.getCarid());
	}
	if(c.getCbrand()!=null) {
		System.out.println(c.getCbrand());
		sql.append(" and cbrand like  concat('%','"+c.getCbrand()+"','%') ");//concat ��ƴ�Ӹ��ӵ�sql���   ʹ��likeģ����ѯ
		//sql.append(" and cbrand like '%").append(c.getCbrand()+"%").append("'");//(" and mobile like '%").append(mobile+"%").append("'")
	}
	if(c.getCpart()!=null) {//ģ����ѯ
		sql.append(" and cpart like  concat('%','"+c.getCpart()+"','%') ");
	}
	if(c.getCprice()!=0) {
		sql.append(" and cprice<"+c.getCprice());
	}
	if(c.getCtype()!=null) {
		sql.append(" and ctype like '%"+c.getCtype()+"%'");//ģ����ѯ
	}
	if(c.getCstatus()!=0) {
		sql.append(" and cstatus="+c.getCstatus());
	}
	if(c.getCgrade()!=0) {
		sql.append(" and cgrade="+c.getCgrade());
	}
	if(c.getIsdelete()!=0) {
		sql.append(" and isdelete="+c.getIsdelete());
	}
	
	String str=new String(sql.toString());
	//System.out.println(str);
	ResultSet rs= getRes(str);//��ѯ
	List<Car> list=new ArrayList<Car>();
	Car car=null;
	try {
		while(rs.next()) {
			car=new Car(rs.getInt("carid"),rs.getString("cbrand"), rs.getDouble("cprice"),
					rs.getString("cpart"), rs.getInt("cstatus"), rs.getInt("cgrade"),rs.getString("ctype"),rs.getInt("isdelete"));
			list.add(car);
		}
		//System.out.println(list.size());
		return list;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return list;
	}
	
	//�޸ĳ���״̬ ͨ��id
	public void changeStatus(int carid,int cstatus) {
		String sql="update car set cstatus=? where carid=?";
		Object[] obj={cstatus,carid};
		getUpda(sql,obj);
	}
	
	
	
	//���ӳ���
	public int addNewCar(User us,Car c) {//���س����������history��¼
		ResultSet rs=getRes("select max(carid) from car");
		int num=0;
		try {
			if(rs.next()) {
				num=rs.getInt(1)+1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sql="insert into car values(?,?,?,?,?,?,?,?)";
		Object[] obj=new Object[] {num,c.getCbrand(),c.getCprice(),c.getCpart(),1,c.getCgrade(),c.getCtype(),0};
		getUpda(sql, obj);//������Ϣ�־û�
		return num;
	}
			
			
	//�Ƴ�����
	public void remove(User us,Car c) {
		String sql="update car set isdelete=1 where carid=?";//isdelete��Ϊ1���ʾ��ɾ��
		Object [] obj= {c.getCarid()};
		getUpda(sql, obj);//ɾ����Ϣ�־û�
	}
	
}
