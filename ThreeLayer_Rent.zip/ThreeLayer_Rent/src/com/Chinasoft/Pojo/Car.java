package com.Chinasoft.Pojo;

public class Car {
	
	private int carid;
	private String cbrand;
	private double cprice;
	private String cpart;
	private int cstatus;
	private int cgrade;
	private String ctype;
	private int isdelete;
	
	public Car() {}
	
	public Car(int carid,String cbrand,double cprice,String cpart,int cstatus,int cgrade,String ctype,int isdelete) {
		this.carid=carid;
		this.cbrand=cbrand;
		this.cprice=cprice;
		this.cpart=cpart;
		this.cstatus=cstatus;
		this.cgrade=cgrade;
		this.ctype=ctype;
		this.isdelete=isdelete;
	}
	
	
	public int getCarid() {
		return carid;
	}
	public void setCarid(int carid) {
		this.carid = carid;
	}
	public String getCbrand() {
		return cbrand;
	}
	public void setCbrand(String cbrand) {
		this.cbrand = cbrand;
	}
	public double getCprice() {
		return cprice;
	}
	public void setCprice(double cprice) {
		this.cprice = cprice;
	}
	public String getCpart() {
		return cpart;
	}
	public void setCpart(String cpart) {
		this.cpart = cpart;
	}
	public int getCstatus() {
		return cstatus;
	}
	public void setCstatus(int cstatus) {
		this.cstatus = cstatus;
	}
	public int getCgrade() {
		return cgrade;
	}
	public void setCgrade(int cgrade) {
		this.cgrade = cgrade;
	}
	public String getCtype() {
		return ctype;
	}
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}

	public int getIsdelete() {
		return isdelete;
	}

	public void setIsdelete(int isdelete) {
		this.isdelete = isdelete;
	}
	
	
	
	
}
