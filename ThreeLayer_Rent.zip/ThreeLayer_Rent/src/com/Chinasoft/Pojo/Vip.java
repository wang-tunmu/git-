package com.Chinasoft.Pojo;

public class Vip {
	
	private int vid;
	private String uname;
	private String opentime;
	private String limittime;
	
	public Vip() {}
	
	public Vip(int vid,String uname,String opentime,String limittime) {
		this.vid=vid;
		this.uname=uname;
		this.opentime=opentime;
		this.limittime=limittime;
	}
	
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getOpentime() {
		return opentime;
	}
	public void setOpentime(String opentime) {
		this.opentime = opentime;
	}
	public String getLimittime() {
		return limittime;
	}
	public void setLimittime(String limittime) {
		this.limittime = limittime;
	}
	
	
}
