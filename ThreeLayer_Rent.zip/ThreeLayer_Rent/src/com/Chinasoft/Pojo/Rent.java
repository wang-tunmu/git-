package com.Chinasoft.Pojo;

public class Rent {
	
	private int rid;
	private String uname;
	private int cid;
	private String rtime;
	private String btime;
	private double money;
	
	public Rent() {}
	
	public Rent(int rid,String uname,int cid,String rtime,String btime,double money) {
		this.rid=rid;
		this.uname=uname;
		this.cid=cid;
		this.rtime=rtime;
		this.btime=btime;
		this.setMoney(money);
	}
	
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getRtime() {
		return rtime;
	}
	public void setRtime(String rtime) {
		this.rtime = rtime;
	}
	public String getBtime() {
		return btime;
	}
	public void setBtime(String btime) {
		this.btime = btime;
	}

	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}
	
	
	
	
}
