package com.Chinasoft.Pojo;

public class History {
	
	private int hid;
	private String uname;
	private int cid;
	private String username;
	private String htime;
	private String htype;
	
	public History() {}
	
	public History(int hid,String uname,int cid,String username,String htime,String htype) {
		this.hid=hid;
		this.uname=uname;
		this.cid=cid;
		this.username=username;
		this.htime=htime;
		this.htype=htype;
	}
	
	
	public int getHid() {
		return hid;
	}
	public void setHid(int hid) {
		this.hid = hid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getHtime() {
		return htime;
	}
	public void setHtime(String htime) {
		this.htime = htime;
	}
	public String getHtype() {
		return htype;
	}
	public void setHtype(String htype) {
		this.htype = htype;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}

	
	
	
}
