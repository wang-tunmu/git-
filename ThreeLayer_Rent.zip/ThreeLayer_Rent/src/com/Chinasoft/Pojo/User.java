package com.Chinasoft.Pojo;

public class User {
	
	private int uid;
	private String uname;
	private String upassword;
	private int power;//0Ϊ��ͨ�û���1Ϊ��Ա��2Ϊ����Ա
	private String idname;
	private String idcard;
	private String phonenumber;
	
	public User() {}
	
	public User(int uid,String uname,String upassword,int power,String idname,String idcard,String phonenumber) {
		this.uid=uid;
		this.uname=uname;
		this.power=power;
		this.upassword=upassword;
		this.idname=idname;
		this.idcard=idcard;
		this.phonenumber=phonenumber;
	}
	
	
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpassword() {
		return upassword;
	}
	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}
	public int getPower() {
		return power;
	}
	public void setPower(int power) {
		this.power = power;
	}
	public String getIdname() {
		return idname;
	}
	public void setIdname(String idname) {
		this.idname = idname;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	
	
}
