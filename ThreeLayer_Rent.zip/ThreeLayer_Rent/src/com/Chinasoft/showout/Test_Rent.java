package com.Chinasoft.showout;

import com.Chinasoft.serviceImpl.SignImpl;

public class Test_Rent {
	
	public static void main(String[] args) {

		SignImpl ri=new SignImpl();
		ri.choice();
		
	}	
}
